package com.example.utils

const val BASE_URL = "https://api.openweathermap.org"