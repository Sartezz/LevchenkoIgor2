package com.example.data.rest.entity

data class CoordResponse(val lon: String, val lat: String)