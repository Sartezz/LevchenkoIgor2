package com.example.domain.entity

data class WeatherLiveData(val weatherInfo: WeatherInfo, var isLoading: Boolean)