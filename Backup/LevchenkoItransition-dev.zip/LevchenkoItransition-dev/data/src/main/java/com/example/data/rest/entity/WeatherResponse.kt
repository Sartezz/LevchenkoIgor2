package com.example.data.rest.entity

data class WeatherResponse(val id: Int, val main: String, val description: String, val icon: String)