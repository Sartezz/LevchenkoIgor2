package com.example.data.rest.entity

data class WindResponse(val speed: Double, val deg: Int)