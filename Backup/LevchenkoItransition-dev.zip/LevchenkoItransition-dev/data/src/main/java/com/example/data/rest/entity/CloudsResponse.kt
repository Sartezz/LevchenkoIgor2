package com.example.data.rest.entity

data class CloudsResponse(val all: Int)